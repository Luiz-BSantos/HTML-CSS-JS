function apagar(){
    document.getElementById('luz').src='ligada.gif'
}
function ligar(){
    document.getElementById('luz').src='desligada.gif'
}